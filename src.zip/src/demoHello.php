<?php

namespace demo\Hello;

class demoHello {

	public function sayHello() {

		return 'Hello!!';

	}

}